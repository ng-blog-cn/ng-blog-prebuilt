import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  templateUrl: './app.component.html'
})
export class AppComponent { }
