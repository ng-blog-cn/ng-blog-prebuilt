import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: '<toh-heroes></toh-heroes>'
})
export class AppComponent { }
