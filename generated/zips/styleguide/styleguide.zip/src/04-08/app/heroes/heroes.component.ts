import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'toh-heroes',
  templateUrl: './heroes.component.html'
})
export class HeroesComponent implements OnInit {
  constructor() { /* ... */ }

  ngOnInit() { /* ... */ }
}
