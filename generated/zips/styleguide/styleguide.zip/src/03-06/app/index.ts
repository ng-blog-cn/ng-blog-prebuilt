export * from './heroes';
export * from './core';
export * from './app.component';
