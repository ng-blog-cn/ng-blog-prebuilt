import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: `<toh-toast></toh-toast>`
})
export class AppComponent { }
