import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { HeroService } from './hero.service';

@Injectable()
export class HeroArena {
  constructor(
    private heroService: HeroService,
    private http: Http) {}
    // test harness
    getParticipants() {
      return this.heroService.getHeroes();
    }
}
