import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: '<toh-hero-list></toh-hero-list>'
})
export class AppComponent { }
