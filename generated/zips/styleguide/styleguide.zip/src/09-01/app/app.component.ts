import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: '<toh-hero-button></toh-hero-button>'
})
export class AppComponent { }
