export * from './shared';
export * from './heroes.component';
