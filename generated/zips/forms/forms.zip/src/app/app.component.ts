import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-hero-form></app-hero-form>'
})
export class AppComponent { }
