import { Attribute, Component, Inject, Optional } from '@angular/core';

@Component({
  selector: 'hero-title',
  templateUrl: './hero-title.component.html'
})
export class HeroTitleComponent {
  msg = '';
  constructor(
    @Inject('titlePrefix') @Optional() private titlePrefix: string,
    @Attribute('title') private title: string
  ) { }

  ok() {
    this.msg = 'OK!';
  }
}
