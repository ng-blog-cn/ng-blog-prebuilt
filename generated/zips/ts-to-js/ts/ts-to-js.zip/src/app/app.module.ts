/* tslint:disable-next-line:no-unused-variable */
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ConfirmComponent } from './confirm.component';
import { HeroComponent } from './hero.component';
import { HeroComponent as HeroDIComponent } from './hero-di.component';
import { HeroComponent as HeroDIInjectComponent } from './hero-di-inject.component';
import { HeroComponent as HeroDIInjectAdditionalComponent } from './hero-di-inject-additional.component';
import { HeroHostComponent } from './hero-host.component';
import { HeroHostMetaComponent } from './hero-host-meta.component';
import { HeroIOComponent } from './hero-io.component';
import { HeroComponent as HeroLifecycleComponent } from './hero-lifecycle.component';
import { HeroQueriesComponent, ViewChildComponent, ContentChildComponent } from './hero-queries.component';
import { HeroTitleComponent } from './hero-title.component';

import { DataService } from './data.service';

@NgModule({
  imports: [
    BrowserModule
  ],
  declarations: [
    AppComponent,
    ConfirmComponent,
    HeroComponent,
    HeroDIComponent,
    HeroDIInjectComponent,
    HeroDIInjectAdditionalComponent,
    HeroHostComponent, HeroHostMetaComponent,
    HeroIOComponent,
    HeroLifecycleComponent,
    HeroQueriesComponent, ViewChildComponent, ContentChildComponent,
    HeroTitleComponent
  ],
  providers: [
    DataService,
    { provide: 'heroName', useValue: 'Windstorm' }
  ],
  bootstrap: [ AppComponent ],

  // schemas: [ NO_ERRORS_SCHEMA ] // helpful for debugging!
})
export class AppModule { }

/* tslint:disable no-unused-variable */
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {
  LocationStrategy,
  HashLocationStrategy
} from '@angular/common';
