import { Component } from '@angular/core';

@Component({
  selector: 'hero-di-inject-additional',
  template: `<hero-title title="Tour of Heroes"></hero-title>`
})
export class HeroComponent { }
