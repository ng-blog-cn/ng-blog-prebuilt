// main app entry point
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BagModule } from './bag';

platformBrowserDynamic().bootstrapModule(BagModule);
